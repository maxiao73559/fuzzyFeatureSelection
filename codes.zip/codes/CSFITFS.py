from csfuzzyMI import *


def CSFITFS(sim_x,sim_y,cIdx, K, ** kwargs):
    n_features = len(sim_x)
    is_n_selected_features = True

    n_selected_features = K

    #选择的特征
    F = []
    j_cmi = 1
    # I（fi ；y）
    t1 = np.zeros(n_features)
    t2 = np.ones(n_features)*1000000
    t3 = np.zeros(n_features)

    for i in range(n_features):
        t1[i] += mutual_information(sim_x[i],sim_y,cIdx)
    while True:
        #第一个特征
        if len(F) == 0:
            idx = np.argmax(t1)
            F.append(idx)
            f_select = idx
        if is_n_selected_features:
            if len(F) == n_selected_features:
                break

        j_cmi = -1E30
        for i in range(n_features):
            if i not in F:
                MI = mutual_information(np.minimum(sim_x[i],sim_x[f_select]),sim_y,cIdx)
                t2[i] = np.minimum(MI- mutual_information(sim_x[i],sim_x[f_select],cIdx),t2[i])
                t = t2[i]
                if t > j_cmi:
                    j_cmi = t
                    idx = i
                #找到最大的t对应的特征

        F.append(idx)
        f_select = idx
        
    return F

