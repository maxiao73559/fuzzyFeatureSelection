from fuzzyMI import *


def FJMIM(rx, ry, K, ** kwargs):

    n_features = len(rx)
    is_n_selected_features = True
    n_selected_features = K

    #选择的特征
    F = []
    temp_R = np.ones((n_features,n_features))
    j_cmi = 1
    # I（fi ; y）
    t1 = np.zeros(n_features)  
    # I（S U {fk};y）
    t2 = np.zeros(n_features)  

    for i in range(n_features):
        t2[i] = 1E30
        t1[i] += mutual_information(rx[i],ry)
    
    while True:
        #第一个特征
        if len(F) == 0:
            idx = np.argmax(t1)
            F.append(idx)
            f_select = idx
        if is_n_selected_features:
            if len(F) == n_selected_features:
                break
        else:
            if j_cmi < 0:
                break

        j_cmi = -1E30
        beta = 1.0 / len(F)
        for i in range(n_features):
            if i not in F:
                MI = mutual_information(np.minimum(rx[i],rx[f_select]),ry)
                t2[i] = np.minimum(2*MI- t1[i] - t1[f_select],t2[i])
            
                #找到最大的t对应的特征
                if t2[i] > j_cmi:
                    j_cmi = t2[i]
                    idx = i
                    # temp_R = joinR
        F.append(idx)
        # x = temp_R
        f_select = idx
    return F

