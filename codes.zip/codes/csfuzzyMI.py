from binascii import crc_hqx
import scipy.io as scio
from math import log
import numpy as np
import math
# import gc

def Gaussian_fuzzy_equivalence(x):
    N = len(x)
    T = np.ones((1,N))
    if np.std(x,ddof=1) == 0:
        return np.ones((N,N))
    r = np.exp(-(np.dot(x,T)-np.dot(T.T,x.T))**2 / (2*np.std(x,ddof=1)**2))
    return r


def dispersed_fuzzy_equivalence(x):
    N = len(x)
    T = np.ones((1,N))
    r = np.dot(x,T)-np.dot(T.T,x.T)
    r = 1*(r==0)
    return r
    
def cal_GFE(X,Y,meta=None):
    n_samples, n_features = X.shape
    rx = np.zeros((n_features,n_samples,n_samples))
    ry = np.zeros((n_samples,n_samples))
    if meta :
        for i in range(n_features):
            types = meta.types()[i]
            if types == 'nominal':
                rx[i,:,:]=dispersed_fuzzy_equivalence(X[:,i].reshape(-1,1))
            else:
                rx[i,:,:]=Gaussian_fuzzy_equivalence(X[:,i].reshape(-1,1))
    else :
        for i in range(n_features):
            rx[i,:,:]=Gaussian_fuzzy_equivalence(X[:,i].reshape(-1,1))
    ry = dispersed_fuzzy_equivalence(Y.reshape(-1, 1))
    return rx,ry

#H(fk)Y=y
def entropy(r,cIdx):
    N = len(r)
    cr = r[cIdx,:]
    card = np.log2(np.sum(cr,axis=1)/N)
    H = -np.sum(card)/N
    return H

#H(fk,fs)
def joint_entropy(rx,cIdx):
    N = len(rx)
    N_sam = len(rx[0])
    joinR = np.ones((N_sam,N_sam))
    for i in range(N):
         joinR = np.minimum(joinR,rx[i])
    cjoinR = joinR[cIdx,:]
    card = np.log2(np.sum(cjoinR,axis=1)/N_sam)
    H = -np.sum(card)/N_sam
    return H

#H(X|Y)
def conditional_entropy(rx,ry,cIdx):
    n_feax = len(rx)
    n_feay = len(ry)
    N_sam = len(rx[0])
    joinR2 = np.ones((N_sam,N_sam))
    for i in range(n_feay):
        joinR2 = np.minimum(joinR2,ry[i])

    joinR1 = joinR2.copy()
    for i in range(n_feax):
        joinR1 = np.minimum(joinR1,rx[i])
    cjoinR1 = joinR1[cIdx,:]
    cjoinR2 = joinR2[cIdx,:]
    card = np.log2( np.sum(cjoinR1,axis=1)/np.sum(cjoinR2,axis=1)  )
    H = -np.sum(card)/N_sam
    return H

#MI(fk;fs)Y=y
def mutual_information(rx,ry,cIdx):
    N = len(rx)
    crx = rx[cIdx,:]
    cry = ry[cIdx,:]
    joinR = np.minimum(rx,ry)
    cjoinR = joinR[cIdx,:]
    card =np.log2( (np.sum(crx,axis=1)*np.sum(cry,axis=1) )/(N * np.sum(cjoinR,axis=1)))
    MI = -np.sum(card)/N
    return MI

#MI(X;Y|Z)
def conditional_MI(rx, ry,rz,cIdx):
    N = len(rx)
    joinR1 = np.minimum(rx,rz)
    joinR2 = np.minimum(ry,rz)
    joinR3 = np.minimum(joinR1,ry)
    cjoinR1 = joinR1[cIdx,:]
    cjoinR2 = joinR2[cIdx,:]
    cjoinR3 = joinR3[cIdx,:]
    crz = rz[cIdx,:]
    card =np.log2( (np.sum(cjoinR1,axis=1)*np.sum(cjoinR2,axis=1) )/(np.sum(crz,axis=1) * np.sum(cjoinR3,axis=1)))
    MI = -np.sum(card)/N

    return MI
