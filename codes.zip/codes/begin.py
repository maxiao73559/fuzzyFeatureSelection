from scipy.io import arff
import pandas as pd
import numpy as np
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn import preprocessing
import numpy as np
import codecs
import CSFITFS



def Gaussian_fuzzy_equivalence(x):
    N = len(x)
    T = np.ones((1,N))
    if np.std(x,ddof=1) == 0:
        return np.ones((N,N))
    r = np.exp(-(np.dot(x,T)-np.dot(T.T,x.T))**2 / (2*np.std(x,ddof=1)**2))
    return r


def dispersed_fuzzy_equivalence(x):
    N = len(x)
    T = np.ones((1,N))
    r = np.dot(x,T)-np.dot(T.T,x.T)
    r = 1*(r==0)
    return r


def cal_GFE(X,Y,meta=None):
    n_samples, n_features = X.shape
    rx = np.zeros((n_features,n_samples,n_samples))
    ry = np.zeros((n_samples,n_samples))
    if meta :
        for i in range(n_features):
            types = meta.types()[i]
            if types == 'nominal':
                rx[i,:,:]=dispersed_fuzzy_equivalence(X[:,i].reshape(-1,1))
            else:
                rx[i,:,:]=Gaussian_fuzzy_equivalence(X[:,i].reshape(-1,1))
    else :
        for i in range(n_features):
            rx[i,:,:]=Gaussian_fuzzy_equivalence(X[:,i].reshape(-1,1))
    ry = dispersed_fuzzy_equivalence(Y.reshape(-1, 1))
    return rx,ry


Dataset_all = ['featMIAS', 'musk1', 'movement_libras', 'qsar-biodeg', 'segment', 'wpbc', 'ALLAML', 'Carcinom', 'CLL_SUB_111', 
               'ORL', 'orlraws10P', 'pixraw10P', 'TOX_171', 'warpAR10P', 'warpPIE10P', 'Yale', 'SRBCT', 'Leukemia', 'Lymphoma']


Dataset_name_all = ['featMIAS', 'musk1', 'movement_libras', 'qsar-biodeg', 'segment', 'wpbc', 'ALLAML', 'Carcinom', 'CLL_SUB_111', 
               'ORL', 'orlraws10P', 'pixraw10P', 'TOX_171', 'warpAR10P', 'warpPIE10P', 'Yale', 'SRBCT', 'Leukemia', 'Lymphoma']


class_num_all = [4, 2, 15, 2, 7, 2, 2, 11, 3, 40, 10, 10, 4, 10, 10, 15, 4, 3, 3]

for d_idx in range(0, len(Dataset_name_all)):

    data_now_name = "datasets/" + Dataset_name_all[d_idx] + ".arff"
    data, meta = arff.loadarff(data_now_name)

    print(data_now_name)

    df = pd.DataFrame(data)

    isNumeric = []

    for attr in meta._attributes:

        if meta._attributes[attr][0] == 'numeric':
            isNumeric.append(True)
        elif meta._attributes[attr][0] == 'nominal':

            for i in range(len(df[attr])):
                item = str(df[attr][i], encoding='UTF-8')

                if item == '?':
                    df[attr][i] = item
                    continue

                item = meta._attributes[attr][1].index(item)
                df[attr][i] = item


    Y = df.iloc[:, -1].values.tolist() # 要处理的标签
    
    feature = []

    for attr in meta._attributes:
        temp = df[attr].values.tolist()
        feature.append(temp)

    feature = np.array(feature).T

    feature = feature[:, :-1]

    min_max_scaler = preprocessing.MinMaxScaler()
    min_max_sample = min_max_scaler.fit_transform(feature)
    feature = min_max_sample

    y = np.array(Y)

    alog_all = [CSFITFS.CSFITFS]

    class_num = class_num_all[d_idx]

    if feature.shape[1] > 50:
        K = 50
    else:
        K = int(feature.shape[1] / 2)


    kf = StratifiedKFold(n_splits=10, shuffle=True, random_state=3)

    res_now = []

    for train_index, test_index in kf.split(feature, y):
        X_train, X_test = feature[train_index], feature[test_index]
        y_train, y_test = y[train_index], y[test_index]

        for alog in alog_all:

            print(alog)

            for class_now in range(class_num):

                sim_x, sim_y = cal_GFE(X_train, y_train.ravel())

                cidx = np.argwhere(y_train == class_now).ravel()

                feature_select = alog(sim_x, sim_y, cidx, K)

                for f in feature_select:
                    res_now.append("f" + str(f + 1))

                print(feature_select)
                res_now.append("L一类结束")

        res_now.append("Z一折结束")

    
    filename =  Dataset_name_all[d_idx] + "_class_fnum.txt"

    with codecs.open(filename, 'a', encoding='utf-8') as f:
        for item in res_now:
            f.write(str(item) + '\n')


