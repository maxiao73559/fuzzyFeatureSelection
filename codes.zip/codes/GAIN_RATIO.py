from fuzzyMI import *
import time

def GAIN_RATIO(rx, ry,  K,  ** kwargs):
    n_features = len(rx)
    is_n_selected_features = True

    n_selected_features = K

    #选择的特征
    F = []
    x = []
    j_cmi = 1
    flag = 0
    # I（fi ；y）
    t1 = np.zeros(n_features)  
    # I（fi；f）
    t2 = np.zeros(n_features)  
    hx = np.zeros(n_features)
    for i in range(n_features):
        hx[i] = entropy(rx[i])
        if hx[i] == 0:
            t1[i]+=0
        else:
            t1[i] += mutual_information(rx[i],ry)/hx[i]
    
    while True:
        #第一个特征
        if len(F) == 0:
            idx = np.argmax(t1)
            F.append(idx)
            x = rx[idx]
        if is_n_selected_features:
            if len(F) == n_selected_features:
                break

        j_cmi = -1E30
        for i in range(n_features):
            if i not in F:
                t,joinR = gain(x,ry,rx[i])
                if hx[i] == 0:
                    t = 0
                else:
                    t = t / hx[i]
                #找到最大的t对应的特征
                if t > j_cmi:
                    j_cmi = t
                    idx = i
                    temp_R = joinR
        # if t <= 0 and flag==0:
        #     flag = 1
        #     print(" GAIN_RATIO_AS_FRS选择的特征个数是 ：",len(F))
        #     break
        F.append(idx)
        x = temp_R

    return F

