from fuzzyMI import *


def FMI_mRMD(rx, ry, K, ** kwargs):
    n_features = len(rx)
    is_n_selected_features = True
    n_selected_features = K

    #选择的特征
    F = []
    temp_R = np.ones((n_features,n_features))
    j_cmi = 1
    # I（fi ；y）
    t1 = np.zeros(n_features)  
    # I（fk ；fs）
    t3 = np.zeros(n_features)
    for i in range(n_features):
        t1[i] += mutual_information(rx[i],ry)
    
    while True:
        #第一个特征
        if len(F) == 0:
            idx = np.argmax(t1)
            F.append(idx)
            x = rx[idx]
            f_select = idx
        if is_n_selected_features:
            if len(F) == n_selected_features:
                break
        else:
            if j_cmi < 0:
                break

        j_cmi = -1E30
        beta = 1.0 / len(F)
        for i in range(n_features):
            if i not in F:
                t2 = mutual_information(np.minimum(x, rx[i]),ry)
                t3[i] += mutual_information(rx[i], rx[f_select])
                t = t2 - beta*t3[i]
                #找到最大的t对应的特征
                if t > j_cmi:
                    j_cmi = t
                    idx = i
        F.append(idx)
        x = np.minimum(x,rx[idx])
        f_select = idx
    return F