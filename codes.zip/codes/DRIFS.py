from scipy.spatial.distance import pdist, squareform
import numpy as np

def distcorr(X, Y):
    """ Compute the distance correlation function
    
    >>> a = [1,2,3,4,5]
    >>> b = np.array([1,2,9,4,4])
    >>> distcorr(a, b)
    0.762676242417
    """
    X = np.atleast_1d(X)
    Y = np.atleast_1d(Y)
    if np.prod(X.shape) == len(X):
        X = X[:, None]
    if np.prod(Y.shape) == len(Y):
        Y = Y[:, None]
    X = np.atleast_2d(X)
    Y = np.atleast_2d(Y)
#     print(X,Y)
    n = X.shape[0]
    if Y.shape[0] != X.shape[0]:
        raise ValueError('Number of samples must match')
    a = squareform(pdist(X))
    b = squareform(pdist(Y))
    A = a - a.mean(axis=0)[None, :] - a.mean(axis=1)[:, None] + a.mean()
    B = b - b.mean(axis=0)[None, :] - b.mean(axis=1)[:, None] + b.mean()
    
    dcov2_xy = (A * B).sum()/float(n * n)
    dcov2_xx = (A * A).sum()/float(n * n)
    dcov2_yy = (B * B).sum()/float(n * n)
    if np.sqrt(np.sqrt(dcov2_xx) * np.sqrt(dcov2_yy))==0:
        return 0
    dcor = np.sqrt(dcov2_xy)/np.sqrt(np.sqrt(dcov2_xx) * np.sqrt(dcov2_yy))
    return dcor
def DRIFS(X, y, labelCount, K, **kwargs):
    n_samples, n_features = X.shape
    # index of selected features, initialized to be empty
    F = []
    # indicate whether the user specifies the number of features
    is_n_selected_features_specified = True
    n_selected_features = K

    cIdx = {}
    for i in range(labelCount):
        cIdx[i] = np.argwhere(y == i).ravel()
    ave = np.zeros(labelCount)
    R = np.zeros(n_features)
    for i in range(n_features):
        for j in range(labelCount):
            # print(X[cIdx[j],i])
            ave[j] = np.mean(X[cIdx[j],i])
        R[i] = np.std(ave,ddof=1)**2
    # print(R)
    DR = R.copy()
    # DR = R
    while True:
        if len(F) == 0:
            # select the feature whose mutual information is the largest
            idx = np.argmax(DR)
            F.append(idx)
            f_select = X[:, idx]
            idx_select = idx
        if is_n_selected_features_specified:
            if len(F) == n_selected_features:
                break
        else:
            if j_cmi < 0:
                break

        # we assign an extreme small value to j_cmi to ensure it is smaller than all possible values of j_cmi
        j_cmi = -1E30
        for i in range(n_features):
            if i not in F:
                temp = 0
                for j in range(labelCount):
                    temp = temp + distcorr(X[cIdx[j],i],X[cIdx[j],idx_select])  
                    # print(temp,distcorr(X[cIdx[j],i],X[cIdx[j],idx_select]) )
                I = temp/labelCount - distcorr(X[:,i],X[:,idx_select])
                # print('I=',I)
                # print(DR[i])
                DR[i] = DR[i] + I*R[i]
                # print(DR[i])
                # record the largest j_cmi and the corresponding feature index
                if DR[i] > j_cmi:
                    j_cmi = DR[i]
                    idx = i
        # for i in range(n_features):
        #     w[i] = w[i] * iw[i]
        # print(R)
        F.append(idx)
        f_select = X[:, idx]
        idx_select = idx
    return np.array(F)

