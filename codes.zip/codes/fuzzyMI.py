import scipy.io as scio
from math import log
import numpy as np
import math
# import gc

def Gaussian_fuzzy_equivalence(x):
    N = len(x)
    T = np.ones((1,N))
    if np.std(x,ddof=1) == 0:
        return np.ones((N,N))
    r = np.exp(-(np.dot(x,T)-np.dot(T.T,x.T))**2 / (2*np.std(x,ddof=1)**2))
    return r

# def Gaussian_fuzzy_equivalence(x):
#     N = len(x)
#     r = np.zeros((N,N))
#     std = np.std(x)
#     T = np.ones((1,N))
#     A = 1 + (1/std)*(np.dot(T.T,x.T) - np.dot(x,T))
#     Anew = A*(A>0)
#     B = 1 - (1/std)*(np.dot(T.T,x.T) - np.dot(x,T))
#     Bnew = B*(B>0)
#     index = Anew<=Bnew

#     C=np.zeros((N,N))
#     C[index]=Anew[index]
#     C[~index]=Bnew[~index]
#     r=C
#     return r

def Gaussian_fuzzy_equivalence11(x):
    N = len(x)
    T = np.ones((1,N))
    min_ele = np.min(x)
    max_ele = np.max(x)
    T = np.ones((1,N))
    r = np.zeros((N,N))
    diff = np.abs(np.dot(x,T)-np.dot(T.T,x.T))/np.abs(max_ele-min_ele)
    D = 1-diff
    r = D*(D>0)
    return r
x = np.array([-0.4,-0.4,-0.3,0.3,0.2,0.2])
x1 = np.array([-0.3,0.2,-0.4,-0.3,-0.3,0])
x2  = np.array([-0.5,-0.1,-0.3,0,0,0])
a = Gaussian_fuzzy_equivalence11(x.reshape(-1,1))
b = Gaussian_fuzzy_equivalence11(x1.reshape(-1,1))
c = Gaussian_fuzzy_equivalence11(x2.reshape(-1,1))

# print(a)
# print(b)
# print(c)
# xx = np.array([[1,0.85,0.88,1,0.93,0.81,0,0],
# [0.85,1,0.74,0.85,0.79,0,0.73,0],
# [0.88,0.74,1,0.88,0.94,0.93,0,0],
# [1,0.85,0.88,1,0.93,0.81,0,0],
# [0.93,0.79,0.94,0.93,1,0.87,0,0],
# [0.81,0,0.93,0.81,0.87,1,0,0],
# [0,0.77,0,0,0,0,1,0.78],
# [0,0,0,0,0,0,0.78,1]])
# yy = np.array([ [0,0,0,0,0,0,0,0],
#                 [1,1,1,1,1,1,1,1],
#                 [0,0,0,0,0,0,0,0],
#                 [1,1,1,1,1,1,1,1],
#                 [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0],
#                 [1,1,1,1,1,1,1,1]])
# yy = np.array([ [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0],
#                 [1,1,1,1,1,1,1,1],
#                 [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0]])
# yy = np.array([ [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0],
#                 [1,1,1,1,1,1,1,1],
#                 [0,0,0,0,0,0,0,0],
#                 [1,1,1,1,1,1,1,1],
#                 [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0],
#                 [0,0,0,0,0,0,0,0]])
# zz = np.minimum(xx,yy)
# print(np.sum(1-xx,axis=1)/8)
# print(np.sum(zz,axis=0))
# print(np.sum(xx,axis=0)/8)
# print(np.sum(zz,axis=0)/np.sum(xx,axis=0))
# print(np.minimum(a,b))
# print(np.minimum(b,c))
# print((0.16+0.3+0.3+0.19+0.3+0.15+0.32+0.55)/16)
# x = np.array([0.4,0.6,0.8,1,0.2,0.6])
# x1 = np.array([0.4,1,0.4,0.8,1,0.6])
# a = Gaussian_fuzzy_equivalence11(x.reshape(-1,1))
# b = Gaussian_fuzzy_equivalence11(x1.reshape(-1,1))
# print(a)
# print(b)
# print(np.minimum(a,b))

# def Gaussian_fuzzy_equivalence(x):
#     N = len(x)
#     thta = 1
#     T = np.ones((1,N))

#     r = np.zeros((N,N))
#     diff = np.abs(np.dot(x,T)-np.dot(T.T,x.T))
#     D = 1-diff/thta
#     r = D*(diff<thta)
#     return r


def dispersed_fuzzy_equivalence(x):
    N = len(x)
    T = np.ones((1,N))
    r = np.dot(x,T)-np.dot(T.T,x.T)
    r = 1*(r==0)
    return r
    
def cal_GFE(X,Y,meta=None):
    n_samples, n_features = X.shape
    rx = np.zeros((n_features,n_samples,n_samples))
    ry = np.zeros((n_samples,n_samples))
    if meta :
        for i in range(n_features):
            types = meta.types()[i]
            if types == 'nominal':
                rx[i,:,:]=dispersed_fuzzy_equivalence(X[:,i].reshape(-1,1))
            else:
                rx[i,:,:]=Gaussian_fuzzy_equivalence(X[:,i].reshape(-1,1))
    else :
        for i in range(n_features):
            rx[i,:,:]=Gaussian_fuzzy_equivalence(X[:,i].reshape(-1,1))
    # for i in range(n_features):
    #     rx[i,:,:]=dispersed_fuzzy_equivalence(X[:,i].reshape(-1,1))
    ry = dispersed_fuzzy_equivalence(Y.reshape(-1, 1))
    # ry = Gaussian_fuzzy_equivalence(Y.reshape(-1, 1))
    # ry = 1*(ry>=1)
    
    return rx,ry

#H(X)
def entropy(r):
    N = len(r)

    card = np.log2(np.sum(r,axis=1)/N)
    H = -np.sum(card)/N
    return H

#H(X,Y)
def joint_entropy(rx):
    N = len(rx)
    N_sam = len(rx[0])
    joinR = np.ones((N_sam,N_sam))
    for i in range(N):
         joinR = np.minimum(joinR,rx[i])
    card = np.log2(np.sum(joinR,axis=1)/N_sam)
    H = -np.sum(card)/N_sam
    return H

#H(X|Y)
def conditional_entropy(rx,ry):
    n_feax = len(rx)
    n_feay = len(ry)
    N_sam = len(rx[0])
    joinR2 = np.ones((N_sam,N_sam))
    for i in range(n_feay):
        joinR2 = np.minimum(joinR2,ry[i])

    joinR1 = joinR2.copy()
    for i in range(n_feax):
        joinR1 = np.minimum(joinR1,rx[i])

    card = np.log2( np.sum(joinR1,axis=1)/np.sum(joinR2,axis=1)  )
    H = -np.sum(card)/N_sam
    return H

#MI(X;Y)
def mutual_information(rx,ry):
    return entropy(ry) - conditional_entropy([ry],[rx])

#MI(X;Y|Z)
def conditional_MI(rx, ry,rz):
    # print(conditional_entropy([rx], [rz]) , conditional_entropy([ry], [rz]) , conditional_entropy([rx, ry], [rz]))
    return conditional_entropy([rx], [rz]) + conditional_entropy([ry], [rz]) - conditional_entropy([rx, ry], [rz])

#gain ( B, D, a)
def gain(joinR,ry,rz):
    N = len(ry)
    
    joinR2 = np.minimum(joinR, ry)
    card1 = np.log2( (np.sum(joinR,axis=1)*np.sum(ry,axis=1)) / (N*np.sum(joinR2,axis=1))  )
    H1 = -np.sum(card1)/N

    joinR = np.minimum(joinR,rz)
    joinR2 = np.minimum(joinR,ry)
    card2 = np.log2( (np.sum(joinR,axis=1)*np.sum(ry,axis=1)) / (N*np.sum(joinR2,axis=1))  )
    H2 = -np.sum(card2)/N
    return H2 - H1 , joinR

def Disc(r,idx):
    n_fea = len(idx)
    N_sam = len(r[0])

    tmp_m = np.ones((N_sam,N_sam))
    for i in range(n_fea):
        tmp_m = np.minimum(tmp_m, r[idx[i]])

    card = 1 - np.sum(tmp_m,axis=1)/N_sam
    H = np.sum(card)/N_sam

    return H

# IDisc ˜(D; B)
def IDisc(rx,idx):
    n_fea = len(idx)
    N_sam = len(rx[0])
    tmp_m = np.ones((N_sam,N_sam))
    for i in range(n_fea):
        tmp_m = np.minimum(tmp_m, rx[idx[i]])
    tmp_m = 1 - tmp_m
    tmp_m = np.minimum(tmp_m, 1-rx[-1])
    card = np.sum(tmp_m,axis=1)/N_sam
    MI = np.sum(card)/N_sam
    return MI

def FICI(rx,i,k):
    I = 2*IDisc(rx,[i]+[k]) - IDisc(rx,[k]) - IDisc(rx,[i])
    return I
