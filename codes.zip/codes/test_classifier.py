from scipy.io import arff
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn import preprocessing
import numpy as np
from sklearn import svm
import copy
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import RandomForestClassifier


Dataset_all = ['featMIAS', 'musk1', 'movement_libras', 'qsar-biodeg', 'segment', 'wpbc', 'ALLAML', 'Carcinom', 'CLL_SUB_111', 
               'ORL', 'orlraws10P', 'pixraw10P', 'TOX_171', 'warpAR10P', 'warpPIE10P', 'Yale', 'SRBCT', 'Leukemia', 'Lymphoma']


Dataset_name_all = ['featMIAS', 'musk1', 'movement_libras', 'qsar-biodeg', 'segment', 'wpbc', 'ALLAML', 'Carcinom', 'CLL_SUB_111', 
               'ORL', 'orlraws10P', 'pixraw10P', 'TOX_171', 'warpAR10P', 'warpPIE10P', 'Yale', 'SRBCT', 'Leukemia', 'Lymphoma']


class_num_all = [4, 2, 15, 2, 7, 2, 2, 11, 3, 40, 10, 10, 4, 10, 10, 15, 4, 3, 3]

for d_idx in range(0, len(Dataset_name_all)):


    data_now_name = "datasets/" + Dataset_name_all[d_idx] + ".arff"
    data, meta = arff.loadarff(data_now_name)
    df = pd.DataFrame(data)


    isNumeric = []
    for attr in meta._attributes:

        if meta._attributes[attr][0] == 'numeric':
            isNumeric.append(True)
        elif meta._attributes[attr][0] == 'nominal':

            for i in range(len(df[attr])):
                item = str(df[attr][i], encoding='UTF-8')

                if item == '?':
                    df[attr][i] = item
                    continue

                item = meta._attributes[attr][1].index(item)
                df[attr][i] = item


    Y = df.iloc[:, -1].values.tolist() # 要处理的标签
    

    feature = []

    for attr in meta._attributes:
        temp = df[attr].values.tolist()
        feature.append(temp)

    feature = np.array(feature).T

    feature = feature[:, :-1]

    min_max_scaler = preprocessing.MinMaxScaler()
    min_max_sample = min_max_scaler.fit_transform(feature)
    feature = min_max_sample

    class_num = class_num_all[d_idx]

    alog_num = 1

    idx_all = {}
    for i in range(0, 10):
        idx_all[i] = []

    count = 0
    alog_idx = 0
    alog_num = 1

    K = 50

    with open("xxx.txt", "r", errors='ignore') as f:
        for line in f.readlines():
            line = line.strip('\n')  #去掉列表中每一个元素的换行符
            
            if line[0] == 'f':
                idx_all[alog_idx].append(int(line[1:]) - 1)

                count += 1
                if count == K * class_num:
                    count = 0
                    alog_idx += 1

                    if alog_idx == alog_num:
                        alog_idx = 0

    res_final = []
    res_final_ACC1 = []

    clf_all_class = [svm.SVC(C=2, kernel='rbf', probability=True,random_state=1), DecisionTreeClassifier(criterion='entropy',random_state=0), AdaBoostClassifier(DecisionTreeClassifier(random_state=1),random_state=0), RandomForestClassifier(random_state=1)]

    clf_class_num = 4

    for clf_index in range(clf_class_num):

        print(clf_all_class[clf_index])

        score_final = {}
        ACC_final1 = {}

        for i in range(1, alog_num + 1):
            score_final[i] = []

        score_all = {}
        ACC_all1 = {}

        alog_idx = 0
        for alog in range(alog_num):

            for k in range(1, K + 1):
                score_all[k] = []
                ACC_all1[k] = []

            y = np.array(Y)
        
            kf = StratifiedKFold(n_splits=10, shuffle=True, random_state=3)
            
            spilt_idx = 0
            for train_index, test_index in kf.split(feature, y):
                X_train, X_test = feature[train_index], feature[test_index]
                y_train, y_test = y[train_index], y[test_index]

                now_idx = spilt_idx * K * class_num
                idx_now_all = idx_all[alog_idx][now_idx : now_idx + (K * class_num)]
                

                for k in range(1, K + 1):

                    clf_all = [0] * class_num

                    for num in range(0, class_num):
                    
                        idx_now = idx_now_all[num * K : num * K + K][:k]

                        X_train_select = X_train[:, idx_now[0]].reshape(-1, 1)
                        for i in range(1, len(idx_now)):
                            X_train_select = np.concatenate((X_train_select, X_train[:, idx_now[i]].reshape(-1, 1)), axis=1)

                        temp_class = copy.deepcopy(clf_all_class)
                        clf_all[num] = temp_class[clf_index].fit(X_train_select, y_train)


                    class_all_1 = []
                    for i in range(0, X_test.shape[0]):

                        temp_prob = [0] * class_num

                        X_test_now = X_test[i, :]

                        for num in range(0, class_num):

                            idx_now = idx_now_all[num * K : num * K + K][:k]
                            X_test_select = X_test_now[idx_now[0]].reshape(-1, 1)

                            for index in range(1, len(idx_now)):
                                X_test_select = np.concatenate((X_test_select, X_test_now[idx_now[index]].reshape(-1, 1)), axis=1)
                        
                            prob_score = clf_all[num].predict_proba(X_test_select)

                            for j in range(class_num):
                                temp_prob[j] += prob_score[0][j]

                        temp_prob = np.array(temp_prob)
                        class_now = np.argmax(temp_prob)

                        class_all_1.append(class_now)


                        if y_test[i] == class_now:
                            score_all[k].append(1)
                        else:
                            score_all[k].append(0)

                    for z in range(len(class_all_1)):
                        if y_test[z] == class_all_1[z]:
                            ACC_all1[k].append(1)
                        else:
                            ACC_all1[k].append(0)


                spilt_idx += 1

            for k in range(1, K + 1):
                score_all[k] = np.array(score_all[k])
                ACC_all1[k] = np.array(ACC_all1[k])
                score_final[alog_idx + 1].append(score_all[k].mean())
                ACC_final1[alog_idx + 1].append(ACC_all1[k].mean()) 

            alog_idx += 1


        for i in range(1, alog_num + 1):
            res_final_ACC1.append(ACC_final1[i])


        acc_all = []
        for i in range(1, alog_num + 1):
            temp = np.array(score_final[i])
            acc_all.append("%0.2f±%0.2f" % (temp.mean() * 100, temp.std() * 100))
            print("%0.2f±%0.2f" % (temp.mean() * 100, temp.std() * 100))

        res_final.append(acc_all)

        


