from fuzzyMI import entropy
from fuzzy_entropy import *


def FJMIIV(sim, K, ** kwargs):
    n_features = len(sim)-1
    is_n_selected_features = True
    n_selected_features = K

    #选择的特征
    F = []
    j_cmi = 1
    # I（fi ；y）
    t1 = np.zeros(n_features)  
    t2 = np.zeros(n_features)  
    t3 = np.zeros(n_features) 
    # sim1 = np.array([0.2,0.5,0.7,0.5,0.1,0.8])
    # sim2 = np.array([0.5,0.3,0,0.5,0.2,0.8])
    # x = fuzzy_mutual_information(sim1,sim2)
    # x = fuzzy_entropy(sim[-1])
    # y = fuzzy_joint_entropy(sim[1],sim[-1])
    # z = fuzzy_mutual_information(sim[1],sim[-1])
    for i in range(n_features):
        fmi = fuzzy_mutual_information(sim[i],sim[-1])
        if np.isnan(fmi):
            t1[i] = -1E30
        else:
            t1[i] += fmi
    now_score = -1E30
    while True:
        #第一个特征
        if len(F) == 0:
            idx = np.argmax(t1)
            pre_score = t1[idx]
            rm = sim[idx,:]
            F.append(idx)
            f_select = idx
        if is_n_selected_features:
            if len(F) == n_selected_features:
                break

        j_cmi = -1E30
        for i in range(n_features):
            if i not in F:
                fmi = fuzzy_mutual_information(rm,sim[-1]) + fuzzy_interaction_information(sim[i],rm,sim[-1])
                if np.isnan(fmi):
                    t2[i] = -1E30
                else:
                    t2[i] = t1[i] + fmi
                t = t2[i]
                if t > j_cmi:
                    j_cmi = t
                    idx = i
                #找到最大的t对应的特征
        rm = np.minimum(rm, sim[idx, :])
        F.append(idx)
        
    return F

