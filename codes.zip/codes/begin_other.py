from scipy.io import arff
import pandas as pd
import numpy as np
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn import preprocessing
import numpy as np
import codecs
from sklearn.preprocessing import KBinsDiscretizer
import UCRFS
import JMIM
import FJMIIV
import FJMIM
import FMI_mRMD
import GAIN_RATIO
import NGFMRI
import DRIFS

def caculate_sim(data,label,p=1):

    # Feature selection method using similarity measure and fuzzy entroropy
    # measures based on the article:

    # P. Luukka, (2011) Feature Selection Using Fuzzy Entropy Measures with
    # Similarity Classifier, Expert Systems with Applications, 38, pp. 4600-4607

    # Function call:
    # feature_selection_sim(data, measure, p)

    # OUTPUTS:
    # data_mod      data with removed feature
    # index_rem     index of removed feature in original data

    # INPUTS:
    # data          dataframe, contains class values
    # measure       fuzzy entropy measure, either 'luca' or 'park'
    #               currently coded
    # p             parameter of Lukasiewicz similarity measure
    #               p in (0, \infty) as default p=1.

    # You need to import 'numpy' as 'np' before using this function
    data = np.concatenate((data, label), axis=1)
    data = pd.DataFrame(data)
    l = int(max(data.iloc[:, -1]))   # -classes in the last column
    m = data.shape[0]               # -samples
    t = data.shape[1] -1           # -features

    # dataold = data.copy()

    idealvec_s = np.zeros((l, t))
    for k in range(l):
        idx = data.iloc[:, -1] == k+1
        idealvec_s[k, :] = data[idx].iloc[:, :-1].mean(axis=0)
    # scaling data between [0,1]
    data_v = data.iloc[:, :-1]
    data_c = data.iloc[:, -1]  # labels
    mins_v = data_v.min(axis=0)
    Ones = np.ones((data_v.shape))
    data_v = data_v + np.dot(Ones, np.diag(abs(mins_v)))

    tmp = []
    for k in range(l):
        tmp.append(abs(mins_v))

    idealvec_s = idealvec_s+tmp

    maxs_v = data_v.max(axis=0)
    # print(maxs_v)
    data_v = np.dot(data_v, np.diag(maxs_v**(-1)))
    tmp2 = []
    for k in range(l):
        tmp2.append(abs(maxs_v))

    idealvec_s = idealvec_s/tmp2

    # Convert the array of feature to a dataframe
    data_vv = pd.DataFrame(data_v)
    data = pd.concat([data_vv, data_c], axis=1, ignore_index=False)

    # sample data
    datalearn_s = data.iloc[:, :-1]

    # similarities
    sim = np.zeros((t, m, l))
    t1 = np.ones((1,m))
    t2 = np.ones((1,l))
    for i in range(t):
        idealvec = idealvec_s[:,i].reshape(-1,1)
        datalearn = datalearn_s.iloc[:, i].values.reshape(-1,1)
        idealvec = np.dot(idealvec,t1).T
        datalearn = np.dot(datalearn,t2)
        sim[i,:,:] = 1-np.abs(idealvec - datalearn)

    # for j in range(m):
    #     for i in range(t):
    #         for k in range(l):
    #             sim[i, j, k] = (1-abs(idealvec_s[k, i]**p -
    #                                   datalearn_s.iloc[j, i])**p)**(1/p)
    sim = sim.reshape(t, m*l)
    return sim

def caculate_sim_dis(data,label,p=1):
    
    data = np.concatenate((data, label), axis=1)
    data = pd.DataFrame(data)
    l = int(max(data.iloc[:, -1]))   # -classes in the last column
    m = data.shape[0]               # -samples
    t = data.shape[1] -1           # -features

    # dataold = data.copy()

    idealvec_s = np.zeros((l, t))
    for k in range(l):
        idx = data.iloc[:, -1] == k+1
        idealvec_s[k, :] = data[idx].iloc[:, :-1].mean(axis=0)
    # scaling data between [0,1]

    # sample data
    datalearn_s = data.iloc[:, :-1]

    # similarities
    sim = np.zeros((t, m, l))

    for j in range(m):
        for i in range(t):
            for k in range(l):
                sim[i, j, k] = abs(idealvec_s[k, i]**p -
                                      datalearn_s.iloc[j, i])
    sim = 1*(sim==0)
    sim = sim.reshape(t, m*l)
    return sim



def Gaussian_fuzzy_equivalence(x):
    N = len(x)
    T = np.ones((1,N))
    if np.std(x,ddof=1) == 0:
        return np.ones((N,N))
    r = np.exp(-(np.dot(x,T)-np.dot(T.T,x.T))**2 / (2*np.std(x,ddof=1)**2))
    return r


def dispersed_fuzzy_equivalence(x):
    N = len(x)
    T = np.ones((1,N))
    r = np.dot(x,T)-np.dot(T.T,x.T)
    r = 1*(r==0)
    return r


def cal_GFE(X,Y,meta=None):
    n_samples, n_features = X.shape
    rx = np.zeros((n_features,n_samples,n_samples))
    ry = np.zeros((n_samples,n_samples))
    if meta :
        for i in range(n_features):
            types = meta.types()[i]
            if types == 'nominal':
                rx[i,:,:]=dispersed_fuzzy_equivalence(X[:,i].reshape(-1,1))
            else:
                rx[i,:,:]=Gaussian_fuzzy_equivalence(X[:,i].reshape(-1,1))
    else :
        for i in range(n_features):
            rx[i,:,:]=Gaussian_fuzzy_equivalence(X[:,i].reshape(-1,1))
    ry = dispersed_fuzzy_equivalence(Y.reshape(-1, 1))
    return rx,ry


Dataset_all = ['featMIAS', 'musk1', 'movement_libras', 'qsar-biodeg', 'segment', 'wpbc', 'ALLAML', 'Carcinom', 'CLL_SUB_111', 
               'ORL', 'orlraws10P', 'pixraw10P', 'TOX_171', 'warpAR10P', 'warpPIE10P', 'Yale', 'SRBCT', 'Leukemia', 'Lymphoma']


Dataset_name_all = ['featMIAS', 'musk1', 'movement_libras', 'qsar-biodeg', 'segment', 'wpbc', 'ALLAML', 'Carcinom', 'CLL_SUB_111', 
               'ORL', 'orlraws10P', 'pixraw10P', 'TOX_171', 'warpAR10P', 'warpPIE10P', 'Yale', 'SRBCT', 'Leukemia', 'Lymphoma']


class_num_all = [4, 2, 15, 2, 7, 2, 2, 11, 3, 40, 10, 10, 4, 10, 10, 15, 4, 3, 3]

for d_idx in range(0, len(Dataset_name_all)):

    data_now_name = "datasets/" + Dataset_name_all[d_idx] + ".arff"
    data, meta = arff.loadarff(data_now_name)

    print(data_now_name)

    df = pd.DataFrame(data)

    isNumeric = []

    for attr in meta._attributes:

        if meta._attributes[attr][0] == 'numeric':
            isNumeric.append(True)
        elif meta._attributes[attr][0] == 'nominal':

            for i in range(len(df[attr])):
                item = str(df[attr][i], encoding='UTF-8')

                if item == '?':
                    df[attr][i] = item
                    continue

                item = meta._attributes[attr][1].index(item)
                df[attr][i] = item


    Y = df.iloc[:, -1].values.tolist() # 要处理的标签
    
    feature = []

    for attr in meta._attributes:
        temp = df[attr].values.tolist()
        feature.append(temp)

    feature = np.array(feature).T

    feature = feature[:, :-1]

    # min_max_scaler = preprocessing.MinMaxScaler()
    # min_max_sample = min_max_scaler.fit_transform(feature)
    # feature = min_max_sample

    est = KBinsDiscretizer(n_bins=5, encode='ordinal', strategy='uniform').fit(feature) # 等宽离散化为5个单元
    feature = est.transform(feature)

    y = np.array(Y)

    sim_x, sim_y = cal_GFE(feature, y.ravel())

    alog_all = [UCRFS.ucrfs, JMIM.jmim]

    class_num = class_num_all[d_idx]

    if feature.shape[1] > 50:
        K = 50
    else:
        K = int(feature.shape[1] / 2)


    kf = StratifiedKFold(n_splits=10, shuffle=True, random_state=3)

    res_now = []

    for train_index, test_index in kf.split(feature, y):
        X_train, X_test = feature[train_index], feature[test_index]
        y_train, y_test = y[train_index], y[test_index]

        for alog in alog_all:

            if alog == DRIFS.DRIFS:
                feature_select = alog(feature, y, class_num, K)
            elif alog == FJMIIV.FJMIIV:
                sim_x_now = caculate_sim(feature, y.reshape(-1, 1))
                sim_y_now = caculate_sim_dis(y.reshape(-1, 1), y.reshape(-1, 1))
                sim=np.concatenate((sim_x_now,sim_y_now),axis=0)
                feature_select = alog(sim, K)
            elif alog == UCRFS.ucrfs or alog == JMIM.jmim:
                feature_select = alog(feature, y, K)
            else:
                feature_select = alog(sim_x, sim_y, K)

        res_now.append("Z一折结束")

    
    filename =  Dataset_name_all[d_idx] + "_fnum.txt"

    with codecs.open(filename, 'a', encoding='utf-8') as f:
        for item in res_now:
            f.write(str(item) + '\n')


