from fuzzyMI import *
def NGFMRI(rx,ry, K, ** kwargs):
    r = list(rx)
    r.append(ry)
    n_features = len(r)-1
    is_n_selected_features = True
    n_selected_features = K

    #选择的特征
    F = []
    Con_prev = 10
    Con = 0
    flag = 0
    # GFMRI
    t1 = np.zeros(n_features)  
    #FICI(x)
    t2 = np.zeros(n_features)
    #Disc(x)
    t3 = np.zeros(n_features)
    #IDisc(x,y)
    t4 = np.zeros(n_features)
    DiscY = Disc(r,[len(r)-1])
    for i in range(n_features):
        t3[i] = Disc(r,[i])
        t4[i] = IDisc(r,[i])
        t1[i] = 2*t4[i]/(  t3[i] + DiscY )
        
    while True:
        #第一个特征
        if len(F) == 0:
            idx = np.argmax(t1)
            F.append(idx)
            # Con = conditional_Disc(r,F)
            f_select = idx
        if is_n_selected_features:
            if len(F) == n_selected_features:
                break

        j_cmi = 0
        for i in range(n_features):
            if i not in F:
                t2[i] += FICI(r,f_select,i)
                t = 2*(t4[i] + t2[i])/(  t3[i] + DiscY )
                #找到最大的t对应的特征
                if t > j_cmi:
                    j_cmi = t
                    idx = i
        # Con_prev =Con
        # Con = conditional_Disc(r,F+[idx])
        # if Con_prev-Con < 0.001 and flag==0:
        #     flag=1
        #     print(" NGFMRI选择的特征个数是 ：",len(F))
        #     break
        F.append(idx)
        f_select = idx
        
    return F
