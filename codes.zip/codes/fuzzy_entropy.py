from re import X
import numpy as np
import pandas as pd

from sklearn import datasets


def caculate_sim(data,label,p=1):

    # Feature selection method using similarity measure and fuzzy entroropy
    # measures based on the article:

    # P. Luukka, (2011) Feature Selection Using Fuzzy Entropy Measures with
    # Similarity Classifier, Expert Systems with Applications, 38, pp. 4600-4607

    # Function call:
    # feature_selection_sim(data, measure, p)

    # OUTPUTS:
    # data_mod      data with removed feature
    # index_rem     index of removed feature in original data

    # INPUTS:
    # data          dataframe, contains class values
    # measure       fuzzy entropy measure, either 'luca' or 'park'
    #               currently coded
    # p             parameter of Lukasiewicz similarity measure
    #               p in (0, \infty) as default p=1.

    # You need to import 'numpy' as 'np' before using this function
    data = np.concatenate((data, label), axis=1)
    data = pd.DataFrame(data)
    l = int(max(data.iloc[:, -1]))   # -classes in the last column
    m = data.shape[0]               # -samples
    t = data.shape[1] -1           # -features

    # dataold = data.copy()

    idealvec_s = np.zeros((l, t))
    for k in range(l):
        idx = data.iloc[:, -1] == k+1
        idealvec_s[k, :] = data[idx].iloc[:, :-1].mean(axis=0)
    # scaling data between [0,1]
    data_v = data.iloc[:, :-1]
    data_c = data.iloc[:, -1]  # labels
    mins_v = data_v.min(axis=0)
    Ones = np.ones((data_v.shape))
    data_v = data_v + np.dot(Ones, np.diag(abs(mins_v)))

    tmp = []
    for k in range(l):
        tmp.append(abs(mins_v))

    idealvec_s = idealvec_s+tmp

    maxs_v = data_v.max(axis=0)
    # print(maxs_v)
    data_v = np.dot(data_v, np.diag(maxs_v**(-1)))
    tmp2 = []
    for k in range(l):
        tmp2.append(abs(maxs_v))

    idealvec_s = idealvec_s/tmp2

    # Convert the array of feature to a dataframe
    data_vv = pd.DataFrame(data_v)
    data = pd.concat([data_vv, data_c], axis=1, ignore_index=False)

    # sample data
    datalearn_s = data.iloc[:, :-1]

    # similarities
    sim = np.zeros((t, m, l))
    t1 = np.ones((1,m))
    t2 = np.ones((1,l))
    for i in range(t):
        idealvec = idealvec_s[:,i].reshape(-1,1)
        datalearn = datalearn_s.iloc[:, i].values.reshape(-1,1)
        idealvec = np.dot(idealvec,t1).T
        datalearn = np.dot(datalearn,t2)
        sim[i,:,:] = 1-np.abs(idealvec - datalearn)

    # for j in range(m):
    #     for i in range(t):
    #         for k in range(l):
    #             sim[i, j, k] = (1-abs(idealvec_s[k, i]**p -
    #                                   datalearn_s.iloc[j, i])**p)**(1/p)
    sim = sim.reshape(t, m*l)
    return sim

def caculate_sim_dis(data,label,p=1):
    
    data = np.concatenate((data, label), axis=1)
    data = pd.DataFrame(data)
    l = int(max(data.iloc[:, -1]))   # -classes in the last column
    m = data.shape[0]               # -samples
    t = data.shape[1] -1           # -features

    # dataold = data.copy()

    idealvec_s = np.zeros((l, t))
    for k in range(l):
        idx = data.iloc[:, -1] == k+1
        idealvec_s[k, :] = data[idx].iloc[:, :-1].mean(axis=0)
    # scaling data between [0,1]

    # sample data
    datalearn_s = data.iloc[:, :-1]

    # similarities
    sim = np.zeros((t, m, l))

    for j in range(m):
        for i in range(t):
            for k in range(l):
                sim[i, j, k] = abs(idealvec_s[k, i]**p -
                                      datalearn_s.iloc[j, i])
    sim = 1*(sim==0)
    sim = sim.reshape(t, m*l)
    return sim
def fuzzy_entropy(sim, measure='luca'):
    # possibility for two different entropy measures
    sim = sim.copy()
    n = len(sim)
    if measure == 'luca':
        # moodifying zero and one values of the similarity values to work with
        # De Luca's entropy measure
        delta = 1e-10
        sim[sim == 0] = delta
        sim[sim == 1] = 1-delta
        H = (-sim*np.log(sim)-(1-sim)*np.log(1-sim)).sum()
    elif measure == 'park':
        H = (np.sin(np.pi/2*sim)+np.sin(np.pi/2*(1-sim))-1).sum()
    return H/n

    
def fuzzy_joint_entropy(sim1,sim2):
    # possibility for two different entropy measures
    sim1 = sim1.copy()
    sim2 = sim2.copy()
    # sim = np.maximum(sim1, sim2)
    sim = np.minimum(sim1, sim2)
    n = len(sim)
    delta = 1e-10
    sim[sim == 0] = delta
    sim[sim == 1] = 1-delta

    H = (-sim*np.log(sim)-(1-sim)*np.log(1-sim)).sum()
    return H/n


def fuzzy_conditional_entropy(sim1, sim2):
    # possibility for two different entropy measures
    sim1= sim1.copy()
    sim2= sim2.copy()
    n = len(sim1)
    # print(sim)
    H = fuzzy_joint_entropy(sim1,sim2)-fuzzy_entropy(sim2)
    return H/n


def fuzzy_mutual_information(sim1, sim2):
    # possibility for two different entropy measures
    sim1 = sim1.copy()
    sim2 = sim2.copy()
    sim = np.maximum(sim1, sim2)
    # sim = np.minimum(sim1, sim2)
    n = len(sim)
    
    delta = 1e-10
    sim[sim == 0] = delta
    sim[sim == 1] = 1-delta
    MI = (-sim*np.log(sim)-(1-sim)*np.log(1-sim)).sum()
    # print(fuzzy_entropy(sim1)/6,fuzzy_entropy(sim2)/6,fuzzy_joint_entropy(sim1,sim2)/6)
    # MI1 =  (fuzzy_entropy(sim1)+fuzzy_entropy(sim2)-fuzzy_joint_entropy(sim1,sim2))/6
    return MI/n


def fuzzy_interaction_information(sim1, sim2,sim3):
    # possibility for two different entropy measures
    sim1 = sim1.copy()
    n = len(sim1)
    sim2 = sim2.copy()
    sim3 = sim3.copy()
# maximum
    # sim12 = np.maximum(sim1,sim2)
    # sim13 = np.maximum(sim1,sim3)
    # sim23 = np.maximum(sim2,sim3)
    # sim123= np.maximum(sim12,sim3)
    sim12 = np.minimum(sim1,sim2)
    sim13 = np.minimum(sim1,sim3)
    sim23 = np.minimum(sim2,sim3)
    sim123= np.minimum(sim12,sim3)
    H1=fuzzy_entropy(sim1)
    H2=fuzzy_entropy(sim2)
    H3=fuzzy_entropy(sim3)
    H12=fuzzy_entropy(sim12)
    H13=fuzzy_entropy(sim13)
    H23=fuzzy_entropy(sim23)
    H123=fuzzy_entropy(sim123)
    MI = -(H1+H2+H3) + (H12 + H13 + H23) - H123
    return MI/n

def fuzzy_joint_mutual_information(sim, idx):
    sim = sim.copy()
    n = len(sim)
    MI1 = fuzzy_interaction_information(sim, idx)
    MI2 = fuzzy_mutual_information(sim, [idx[0], idx[-1]])
    MI3 = fuzzy_mutual_information(sim, [idx[1], idx[-1]])
    MI = MI1 - MI2 - MI3
    return MI/n
